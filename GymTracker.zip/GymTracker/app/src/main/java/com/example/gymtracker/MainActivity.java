package com.example.gymtracker;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.content.SharedPreferences;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content, weekBar;
    SharedPreferences prefs;
    int week = 1;
    final String[][][] DATA = new String[][][] {
      { // day 1
        {"Barbell Bench Press","3","6–10"},{"Incline Dumbbell Press","2","8–12"},{"Cable/Machine Fly","2","10–15"},{"Lateral Raise","3","12–18"},{"Rope Triceps Pushdown","3","10–15"},{"Overhead Rope Triceps Extension","2","10–15"}
      },
      { // day 2
        {"Barbell Squat","3","6–8"},{"Romanian Deadlift","3","8–10"},{"Leg Press","2","10–12"},{"Leg Extension","2","10–15"},{"Leg Curl","2","10–15"},{"Standing Calf Raise","3","10–15"},{"Cable Crunch","3","10–15"}
      },
      { // day 4
        {"Lat Pulldown / Assisted Pull-Up","3","6–10"},{"Seated Cable Row","3","8–12"},{"Chest-Supported Row","2","8–12"},{"Straight-Arm Pulldown","2","12–15"},{"EZ-Bar Curl","3","8–12"},{"Hammer Curl","2","10–15"},{"Back Extension","2","10–15"},{"Forearm Curl","2","12–20"}
      },
      { // day 5
        {"Incline Machine Press","2","8–12"},{"Neutral-Grip Lat Pulldown","2","8–12"},{"Machine Chest Press","2","10–12"},{"Seated Cable Row","2","10–12"},{"Cable/Machine Fly","2","12–15"},{"Lateral Raise","2","12–18"},{"Reverse Pec Deck","2","12–18"},{"Hanging Knee/Leg Raise","3","10–15"}
      }
    };
    final String[] DAYS={"DAY 1","DAY 2","DAY 4","DAY 5"};
    int selectedDay=0;

    @Override public void onCreate(Bundle b){super.onCreate(b); prefs=getSharedPreferences("gym",0); build(); showDay(0);}
    TextView tv(String s,int sp){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(Color.rgb(20,20,20));t.setPadding(0,0,0,0);return t;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextSize(13);b.setAllCaps(false);return b;}
    void build(){
      root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.WHITE);
      TextView title=tv("Gym Tracker",26); title.setTypeface(Typeface.DEFAULT,Typeface.BOLD); title.setPadding(20,22,20,12); root.addView(title,new LinearLayout.LayoutParams(-1,dp(70)));
      TextView sub=tv("6-week strength & hypertrophy program",14);sub.setTextColor(Color.GRAY);sub.setPadding(20,0,20,12);root.addView(sub,new LinearLayout.LayoutParams(-1,dp(34)));
      weekBar=new LinearLayout(this); weekBar.setPadding(12,0,12,8); root.addView(weekBar,new LinearLayout.LayoutParams(-1,dp(52)));
      LinearLayout days=new LinearLayout(this); days.setPadding(8,0,8,8); for(int i=0;i<4;i++){final int d=i;Button x=btn(DAYS[i]);x.setOnClickListener(v->{selectedDay=d;showDay(d);});days.addView(x,new LinearLayout.LayoutParams(0,48,1));} root.addView(days,new LinearLayout.LayoutParams(-1,dp(56)));
      ScrollView sv=new ScrollView(this); content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(16,8,16,24);sv.addView(content);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
      setContentView(root); makeWeeks();
    }
    void makeWeeks(){weekBar.removeAllViews();for(int i=1;i<=6;i++){final int w=i;Button b=btn("W"+i); if(w==week)b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setOnClickListener(v->{week=w;makeWeeks();showDay(selectedDay);});weekBar.addView(b,new LinearLayout.LayoutParams(0,48,1));}}
    void showDay(int d){content.removeAllViews(); TextView h=tv(DAYS[d]+"  •  "+label(d),20);h.setTypeface(Typeface.DEFAULT,Typeface.BOLD);content.addView(h,new LinearLayout.LayoutParams(-1,dp(42)));
      TextView info=tv("Week "+week+"  |  Log your working sets",13);info.setTextColor(Color.GRAY);content.addView(info,new LinearLayout.LayoutParams(-1,dp(32)));
      for(int i=0;i<DATA[d].length;i++) addExercise(DATA[d][i],d,i);
    }
    String label(int d){return new String[]{"CHEST + SHOULDERS + TRICEPS","LEGS + CALVES + ABS","BACK + BICEPS + FOREARMS + LOWER BACK","CHEST + BACK + SHOULDERS + ABS"}[d];}
    void addExercise(String[] e,int d,int idx){
      LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(14,12,14,12);card.setBackgroundColor(Color.rgb(248,248,248));
      TextView name=tv(e[0],17);name.setTypeface(Typeface.DEFAULT,Typeface.BOLD);card.addView(name,new LinearLayout.LayoutParams(-1,dp(30)));
      TextView target=tv(e[1]+" sets  •  "+e[2]+" reps",13);target.setTextColor(Color.GRAY);card.addView(target,new LinearLayout.LayoutParams(-1,dp(28)));
      LinearLayout rows=new LinearLayout(this);rows.setOrientation(LinearLayout.VERTICAL);
      for(int s=0;s<Integer.parseInt(e[1]);s++){LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL); TextView st=tv("Set "+(s+1),13);r.addView(st,new LinearLayout.LayoutParams(dp(48),dp(48))); EditText wt=input("kg",key(d,idx,s,"w")); EditText rp=input("reps",key(d,idx,s,"r")); r.addView(wt,new LinearLayout.LayoutParams(0,dp(48),1)); Space sp=new Space(this);r.addView(sp,new LinearLayout.LayoutParams(dp(8),1));r.addView(rp,new LinearLayout.LayoutParams(0,dp(48),1));rows.addView(r);}
      card.addView(rows); EditText note=input("Note (optional)",key(d,idx,0,"n"));card.addView(note,new LinearLayout.LayoutParams(-1,dp(48)));
      content.addView(card,new LinearLayout.LayoutParams(-1,dp(100+Integer.parseInt(e[1])*52))); Space gap=new Space(this);content.addView(gap,new LinearLayout.LayoutParams(1,dp(10)));
    }
    EditText input(String hint,String key){EditText x=new EditText(this);x.setHint(hint);x.setTextSize(14);x.setSingleLine(true);x.setPadding(12,0,12,0);x.setBackgroundColor(Color.WHITE);x.setText(prefs.getString(key,""));x.setOnFocusChangeListener((v,has)->{if(!has)prefs.edit().putString(key,x.getText().toString()).apply();});return x;}
    String key(int d,int i,int s,String f){return "w"+week+"d"+d+"e"+i+"s"+s+f;}
    int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
}
