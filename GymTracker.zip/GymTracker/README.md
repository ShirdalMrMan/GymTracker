# Gym Tracker

Android app project for the 6-week workout plan shown in the supplied image.

## Included
- Weeks 1–6
- Day 1, Day 2, Day 4, Day 5
- All exercises, prescribed sets and rep ranges
- Per-set weight and reps logging
- Optional exercise notes
- Local on-device persistence using SharedPreferences
- Simple English portrait-phone interface

## Build
Open the project in Android Studio and build `app` -> `assembleDebug`.
The project uses Android Gradle Plugin 8.6.1, compileSdk 35, minSdk 26.
